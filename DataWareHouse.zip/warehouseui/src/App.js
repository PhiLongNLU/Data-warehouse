import { useEffect, useState } from "react";
import axios from "axios";
function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    // Hàm gọi API
    const fetchProducts = async () => {
      try {
        const response = await axios.get(
          `http://10.50.161.212:5000/api/products`
        );

        console.log(response.data);
        setProducts(response.data);
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);
  return (
    <div>
      <h1 style={{ textAlign: "center" }}>Báo cáo giá tivi </h1>
    </div>
  );
}

export default App;
